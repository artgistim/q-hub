# 三份獨立 Engagement 題庫

| 檔案 | 目標專案 | 題號與選項 |
| --- | --- | --- |
| self_advanced.txt | ENG_SELF | N01–N14 五選一，N15 三選一 |
| manager_advanced.txt | ENG_MANAGER | M01–M10 五選一，M11 三選一 |
| buddy_advanced.txt | ENG_BUDDY | B01–B10 五選一，B11 三選一 |

不要把主管與夥伴合成共用 B 問卷。這三個 TXT 是 Advanced TXT 題庫交換格式，並不是 EX 專案封裝；Engagement 介面是否能匯入，依帳號／顧問流程確認。若無匯入選項，依內容建立或使用核准的複製方式。

TXT 不再夾帶一般 Survey 的任務 Embedded Data 宣告。身份、受評者、期別與角色由對應 Engagement 的 participant metadata 設定。匯入題庫不會建立名單、寄信、Workflow 或 Dashboard。

五點題不強迫無法評估者作答；空白不計分。最後一題是無序支持需求，不能把 1／2 當低分。實際平台 QID 與 N／M／B export tag 請另核對。
