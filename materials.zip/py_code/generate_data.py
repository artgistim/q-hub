"""離線教學資料產生器。Python 3.10+，無第三方依賴，不連網、不寄信。"""
import calendar, csv, json, random, argparse
from datetime import date, timedelta
from pathlib import Path
from build_engagement_pack import PROJECTS, build_engagement_pack
ROOT = Path(__file__).resolve().parents[1]
ROLES = ('self','manager','buddy')
MAP = {'learning':(1,3,5),'adaptation':(2,5,6),'performance':(3,7,9),'support':(4,8,10)}
LABELS = dict(zip(MAP,('學習進展','公司適應','工作表現','支援可得性')))
QUESTIONS = {
'self': ['我能掌握目前工作需要的基本知識與技能。','我能適應團隊的合作方式與工作節奏。','我能依約定的品質與時程完成目前交付的工作。','遇到工作困難時，我能及時取得需要的協助。','我清楚知道本月的學習目標。','公司提供的訓練有助於我完成工作。','目前的工作量在我可負荷的範圍內。','我可以安心提出問題或不同意見。','主管清楚說明對我的工作期待。','主管提供的回饋具體且有幫助。','主管願意安排時間了解我的適應狀況。','夥伴能協助我找到需要的資訊或窗口。','夥伴願意主動關心我的學習情形。','夥伴的示範有助於我熟悉團隊的工作方式。','目前你最希望優先獲得哪一項支持？'],
'manager':['這位新人清楚了解目前的學習目標。','這位新人能運用訓練內容處理工作。','這位新人能掌握目前工作需要的基本知識與技能。','這位新人願意提出問題並尋求回饋。','這位新人能適應團隊的合作方式與工作節奏。','這位新人與相關同仁的溝通順暢。','這位新人能依約定的品質與時程完成目前交付的工作。','這位新人遇到工作困難時，能及時取得需要的協助。','目前安排給這位新人的工作量適合其學習階段。','我已和這位新人討論下一階段的發展目標。','下個月你準備優先提供這位新人哪一項支持？'],
'buddy':['這位新人清楚知道常用資訊與工具的位置。','這位新人能找到適當的跨部門聯絡窗口。','這位新人願意在不熟悉的地方提出問題。','這位新人能理解團隊日常合作的流程。','這位新人能掌握目前工作需要的基本知識與技能。','這位新人能適應團隊的合作方式與工作節奏。','這位新人能與同事保持良好的互動。','我有足夠時間協助這位新人。','這位新人能依約定的品質與時程完成目前交付的工作。','這位新人遇到工作困難時，能及時取得需要的協助。','你觀察到這位新人最需要哪一項支持？']}
SCALE_CHOICES = [(1,'非常不同意'),(2,'不同意'),(3,'普通'),(4,'同意'),(5,'非常同意')]
SUPPORT_CHOICES = [(1,'工作技能訓練與實作示範'),(2,'團隊交流與夥伴陪伴'),(3,'工作目標釐清與主管回饋')]
def question_choices(role, number):
    return SUPPORT_CHOICES if number == len(QUESTIONS[role]) else SCALE_CHOICES
PREFIX = {'self':'N','manager':'M','buddy':'B'}
FIELDS = ['project_key','project_type','dataset_scope','deployment_status','assignment_id','cycle_id','subject_eid','subject_name','rater_eid','rater_role','manager_eid','manager_email','buddy_eid','subject_department','hire_date','due_date','cycle_month','instrument_version','is_test']
def add_months(d,n):
    y,m=divmod(d.year*12+d.month-1+n,12); m+=1
    return date(y,m,min(d.day,calendar.monthrange(y,m)[1]))
def write_csv(name, rows, fields=None):
    path=ROOT/name; path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def plan_actions(assignments,responses,as_of,ledger=()):
    """純函式：只產生待辦，不宣稱已寄送；ledger 是已成功執行的 action_key。"""
    done={r['assignment_id'] for r in responses if str(r['finished'])=='1' and r['recorded_date']<=as_of.isoformat()}
    seen=set(ledger); result=[]
    for a in assignments:
        due=date.fromisoformat(a['due_date']); close=due+timedelta(days=14)
        if a['assignment_id'] in done or not due<=as_of<=close: continue
        # 首封尚未確認寄出時只規劃邀請，禁止先催填。
        invite=f"{a['assignment_id']}:invite"
        kind='invite' if invite not in seen else ('reminder7' if as_of>=due+timedelta(days=7) else 'reminder3' if as_of>=due+timedelta(days=3) else '')
        if kind and f"{a['assignment_id']}:{kind}" not in seen:
            result.append({'action_key':f"{a['assignment_id']}:{kind}",'assignment_id':a['assignment_id'],'action':kind,'email':a['Email'],'as_of':as_of.isoformat(),'status':'dry_run'})
    return result

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--seed',type=int,default=20261107); ap.add_argument('--as-of',default='2026-11-07');args=ap.parse_args()
    rng=random.Random(args.seed); today=date.fromisoformat(args.as_of)
    people=[]; departments=['晶片研發部','韌體工程部','製程整合部','產品測試部']
    names=['陳怡君','林柏宇','黃詩涵','張家豪','李佳穎','王冠廷','吳雅婷','劉承翰','蔡宜庭','楊子翔','許庭瑜','鄭宇軒','謝佩珊','洪郁翔','郭思妤','邱哲宇','曾品妍','廖俊傑','賴欣怡','徐睿哲','周宥蓁','葉承恩','蘇怡安','莊凱文']
    for i in range(4):
        for role,prefix,base in [('manager','M',100),('buddy','B',200)]:
            eid=f'{prefix}{base+i}';people.append(dict(eid=eid,name=('許志明','林淑芬','陳建宏','張雅雯')[i] if role=='manager' else ('黃冠宇','李佳蓉','吳承佑','王郁晴')[i],email=f'{eid.lower()}@example.com',department=departments[i],person_type=role,hire_date='2020-01-01'))
    for i,n in enumerate(names):
        people.append(dict(eid=f'E{i+1:03}',name=n,email=f'e{i+1:03}@example.com',department=departments[i%4],person_type='new_hire',hire_date=['2026-07-31','2026-08-15','2026-09-30','2026-10-01'][i%4]))
    byid={p['eid']:p for p in people}; relationships=[]; assignments=[]
    for i,p in enumerate(people[8:]):
        manager=f'M{100+i%4}';buddy=f'B{200+i%4}'
        relationships.append(dict(subject_eid=p['eid'],manager_eid=manager,buddy_eid=buddy,effective_from=p['hire_date'],effective_to=''))
        for month in range(1,7):
            due=add_months(date.fromisoformat(p['hire_date']),month);cycle=f"{p['eid']}-M{month:02}"
            for role,rater in zip(ROLES,(p['eid'],manager,buddy)):
                rid=f'{cycle}-{role}-{rater}';person=byid[rater]
                a=dict(project_key=PROJECTS[role][0],project_type='Engagement',dataset_scope='six_month_planning',deployment_status='requires_repeat_response_validation',assignment_id=rid,cycle_id=cycle,subject_eid=p['eid'],subject_name=p['name'],rater_eid=rater,rater_role=role,manager_eid=manager,manager_email=byid[manager]['email'],buddy_eid=buddy,subject_department=p['department'],hire_date=p['hire_date'],due_date=due.isoformat(),cycle_month=month,instrument_version='v3_engagement_first',is_test=1,Email=person['email'],FirstName=person['name'],LastName='',ExternalDataReference=rater)
                assignments.append(a)
    responses=[]; raw={r:[] for r in ROLES}; alerts=[]; scores=[]
    for i,a in enumerate(assignments):
        due=date.fromisoformat(a['due_date']); end=due+timedelta(days=i%10)
        if end>today or i%9==0:continue
        finished=0 if i%13==0 else 1
        r={k:a[k] for k in FIELDS};r.update(response_id=f'SIM_{i+1:05}',finished=finished,recorded_date=end.isoformat(),response_status='simulation')
        role=a['rater_role']; answers={f'{PREFIX[role]}{j:02}': ('' if i%17==0 and j==2 else rng.choices([1,2,3,4,5],[4,9,22,35,25])[0]) for j in range(1,len(QUESTIONS[role]))}
        answers[f'{PREFIX[role]}{len(QUESTIONS[role]):02}']=rng.choice([1,2,3])
        r.update(answers);raw[role].append(r);responses.append({k:r[k] for k in FIELDS+['response_id','finished','recorded_date','response_status']})
        if finished:
            low=[]
            for dim,indices in MAP.items():
                q=f'{PREFIX[role]}{indices[ROLES.index(role)]:02}';v=answers[q]
                scores.append({**{k:a[k] for k in ['assignment_id','cycle_id','subject_eid','rater_role','project_key','project_type','subject_department','cycle_month']},'dimension':dim,'dimension_label':LABELS[dim],'question_id':q,'score':v if v in (1,2,3,4,5) else '', 'response_id':r['response_id']})
                if v in (1,2):low.append(dim)
            if low:alerts.append(dict(alert_key=a['assignment_id']+':care-v1',assignment_id=a['assignment_id'],subject_eid=a['subject_eid'],recipient=a['manager_email'],reason=';'.join(low),status='dry_run',is_test=1))
    write_csv('data/employees.csv',people);write_csv('data/relationships.csv',relationships);write_csv('data/assignments.csv',assignments)
    write_csv('data/responses_index.csv',responses,FIELDS+['response_id','finished','recorded_date','response_status'])
    for role,rows in raw.items():write_csv(f'data/responses_{role}.csv',rows,FIELDS+['response_id','finished','recorded_date','response_status']+[f'{PREFIX[role]}{j:02}' for j in range(1,len(QUESTIONS[role])+1)])
    write_csv('data/scores_long.csv',scores,['assignment_id','cycle_id','subject_eid','rater_role','project_key','project_type','subject_department','cycle_month','dimension','dimension_label','question_id','score','response_id'])
    write_csv('data/alerts_dry_run.csv',alerts,['alert_key','assignment_id','subject_eid','recipient','reason','status','is_test'])
    # 假設到期首封皆已成功送出，以利演練催填；此檔不是實際寄送紀錄。
    ledger=[{'action_key':a['assignment_id']+':invite','executed_at':a['due_date'],'status':'simulated_success'} for a in assignments if a['due_date']<=today.isoformat()]
    write_csv('data/simulated_ledger.csv',ledger,['action_key','executed_at','status'])
    actions=plan_actions(assignments,responses,today,[x['action_key'] for x in ledger])
    write_csv('data/actions_dry_run.csv',actions,['action_key','assignment_id','action','email','as_of','status'])
    mapping=[dict(dimension=d,label=LABELS[d],self_question=f'N{x[0]:02}',manager_question=f'M{x[1]:02}',buddy_question=f'B{x[2]:02}',valid_values='1|2|3|4|5',missing_values='blank') for d,x in MAP.items()]
    write_csv('data/question_mapping.csv',mapping)
    # 員工身份主檔僅供核對；分角色 POC 名單另產生。
    write_csv('data/ex_participants_people.csv',[{'UniqueIdentifier':p['eid'],'FirstName':p['name'],'LastName':'','Email':p['email'],'department':p['department']} for p in people])
    for role in ROLES:
        lines=['[[AdvancedFormat]]',f'[[Block:{PROJECTS[role][0]}]]']
        for j,q in enumerate(QUESTIONS[role],1):
            lines+=['[[Question:MC:SingleAnswer:Vertical]]',f'[[ID:{PREFIX[role]}{j:02}]]',q,'[[AdvancedChoices]]']
            for v,label in question_choices(role,j):
                lines += [f'[[Choice:{v}]]',label]
        (ROOT/f'surveys/{role}_advanced.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    poc=build_engagement_pack(people,assignments,MAP,LABELS,write_csv)
    payload={'engagement_poc':poc,'project_model':'three_engagement','dataset_scope':'six_month_planning','as_of':today.isoformat(),'seed':args.seed,'people':people,'assignments':assignments,'responses':responses,'scores':scores,'alerts':alerts,'questions':QUESTIONS,'choices':{role:[question_choices(role,j) for j in range(1,len(QUESTIONS[role])+1)] for role in ROLES},'mapping':mapping,'actions':actions}
    (ROOT/'assets/demo-data.js').write_text('window.DEMO = '+json.dumps(payload,ensure_ascii=False)+';\n',encoding='utf-8')
    stats={'curriculum_version':'v3_engagement_first','project_model':'three_engagement','poc_projects':3,'poc_assignments':len(poc['assignments']),'dataset_scope':'six_month_planning','as_of':today.isoformat(),'employees':len(people),'new_hires':24,'assignments':len(assignments),'recorded_responses':len(responses),'completed':sum(r['finished'] for r in responses),'score_rows':len(scores),'alerts':len(alerts),'reminders':len(actions)}
    (ROOT/'data/manifest.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(stats,ensure_ascii=False))
if __name__=='__main__':main()
