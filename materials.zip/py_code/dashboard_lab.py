"""以標準函式庫驗算 EX 儀表板案例；僅讀模擬 CSV，輸出專案內 JSON。"""
import csv
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(name):
    with (ROOT / 'data' / name).open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def latest_finished(rows, as_of):
    """先限制有效完成與快照日，再每任務選最新一筆；同日以 ID 穩定排序。"""
    result = {}
    for row in sorted(rows, key=lambda r: (r['recorded_date'], r['response_id'])):
        if not row['assignment_id']:
            raise ValueError('assignment_id 不可空白')
        if row['finished'] == '1' and row['recorded_date'] <= as_of:
            result[row['assignment_id']] = row
    return result


def main():
    manifest = json.loads((ROOT / 'data/manifest.json').read_text(encoding='utf-8'))
    as_of = manifest['as_of']
    tasks = read('assignments.csv')
    responses = read('responses_index.csv')
    scores = read('scores_long.csv')
    task_map = {r['assignment_id']: r for r in tasks}
    assert len(task_map) == len(tasks), '任務鍵重複'
    assert all(r['is_test'] == '1' for r in tasks), '本練習僅接受模擬任務'
    done = latest_finished(responses, as_of)
    assert set(done) <= set(task_map), '未知任務'
    assert len(done) == manifest['completed']

    due = {k for k, task in task_map.items() if task['due_date'] <= as_of}
    due_done = due & set(done)
    completion = dict(as_of=as_of, grain='assignment', due_tasks=len(due),
                      completed_due_tasks=len(due_done),
                      completion_rate=len(due_done) / len(due) if due else None)
    # 依應交月份歸戶，即使延遲到下月完成，也回補原應交月份。
    months = defaultdict(lambda: {'due_tasks': 0, 'completed': 0})
    late_cross_month = 0
    for key in sorted(due):
        task = task_map[key]
        month = task['due_date'][:7]
        months[month]['due_tasks'] += 1
        months[month]['completed'] += int(key in done)
        if key in done and done[key]['recorded_date'][:7] > month:
            late_cross_month += 1
    completion['by_due_month'] = dict(sorted(months.items()))
    completion['late_completions_in_later_month'] = late_cross_month

    groups = defaultdict(list)
    pairs = defaultdict(dict)
    question_keys = set()
    for row in scores:
        aid = row['assignment_id']
        assert aid in done and row['response_id'] == done[aid]['response_id']
        assert row['score'] in {'', '1', '2', '3', '4', '5'}
        assert row['question_id'] not in {'N15', 'M11', 'B11'}
        key = (aid, row['dimension'])
        assert key not in question_keys, '構念重複，須先決定多題聚合方法'
        question_keys.add(key)
        if row['score'] == '':
            continue
        value = int(row['score'])
        groups[(row['dimension'], row['rater_role'])].append(value)
        pair = pairs[(row['cycle_id'], row['dimension'])]
        assert row['rater_role'] not in pair
        pair[row['rater_role']] = value
    metrics = [dict(dimension=d, role=r, valid_n=len(v), mean=sum(v)/len(v),
                    favorable_n=sum(x >= 4 for x in v), favorability=sum(x >= 4 for x in v)/len(v))
               for (d, r), v in sorted(groups.items())]
    existing_means = {(r['dimension'], r['rater_role']): r for r in read('summary_means.csv')}
    for metric in metrics:
        existing = existing_means[(metric['dimension'], metric['role'])]
        assert metric['valid_n'] == int(existing['valid_n'])
        assert round(metric['mean'], 6) == float(existing['mean'])
    complete_pairs = {key: v for key, v in pairs.items() if set(v) == {'self', 'manager', 'buddy'}}
    existing_pairs = read('paired_gaps.csv')
    assert len(complete_pairs) == len(existing_pairs)
    for row in existing_pairs:
        values = complete_pairs[(row['cycle_id'], row['dimension'])]
        assert values['manager'] - values['self'] == int(row['manager_minus_self'])
        assert values['buddy'] - values['self'] == int(row['buddy_minus_self'])

    # 反例：A 答四題全 5；B 只答一題 1。缺答不是零分。
    respondent_scores = [[5, 5, 5, 5], [1]]
    flattened = [v for person in respondent_scores for v in person]
    item_mean = sum(flattened) / len(flattened)
    person_mean = sum(sum(p)/len(p) for p in respondent_scores) / len(respondent_scores)
    item_favorable = sum(v >= 4 for v in flattened) / len(flattened)
    person_favorable = sum(sum(v >= 4 for v in p)/len(p) for p in respondent_scores) / 2
    assert (item_mean, person_mean, item_favorable, person_favorable) == (4.2, 3.0, 0.8, 0.5)

    # 反例：三人中只有 E1 同時有自評和主管評，未配對的差距會反向。
    self_scores = {'E1': 1, 'E2': 5}
    manager_scores = {'E1': 2, 'E3': 1}
    paired_ids = self_scores.keys() & manager_scores.keys()
    unpaired_gap = sum(manager_scores.values())/2 - sum(self_scores.values())/2
    paired_gap = sum(manager_scores[k]-self_scores[k] for k in paired_ids)/len(paired_ids)
    assert (unpaired_gap, paired_gap) == (-1.5, 1.0)

    # 同任務先完成，後又有未完成紀錄；不能先取最新再判 finished。
    dedup_fixture = [dict(assignment_id='A', response_id='1', finished='1', recorded_date='2026-10-01'),
                     dict(assignment_id='A', response_id='2', finished='0', recorded_date='2026-10-02'),
                     dict(assignment_id='A', response_id='3', finished='1', recorded_date='2026-12-01')]
    assert latest_finished(dedup_fixture, '2026-11-07')['A']['response_id'] == '1'

    poc_assignments=read('engagement_poc_assignments.csv')
    poc_responses=read('engagement_poc_responses.csv')
    poc_mapping=[m for m in read('engagement_dashboard_mapping.csv') if m['field_type']=='Number Set']
    poc_groups=defaultdict(list)
    assert len(poc_assignments)==12
    assert len({(r['project_key'],r['rater_eid']) for r in poc_assignments})==12
    for row in poc_responses:
        assert row['response_status']=='scripted_expected_not_collected'
        for mapping in poc_mapping:
            poc_groups[(mapping['dashboard_field'],row['rater_role'])].append(int(row[mapping[row['project_key']]]))
    poc_metrics=read('engagement_poc_expected_metrics.csv')
    for metric in poc_metrics:
        values=poc_groups[(metric['dimension'],metric['rater_role'])]
        assert len(values)==int(metric['valid_n'])==4
        assert sum(values)/len(values)==float(metric['mean'])
    output = {
        'dataset': '三 Engagement 的六個月規劃模擬；所有 is_test=1，非平台已收集回覆',
        'project_model':'three_engagement',
        'poc':{'assignments':len(poc_assignments),'responses':len(poc_responses),'scope':'scripted_expected_not_collected','expected_metrics':poc_metrics},
        'as_of': as_of, 'completion': completion,
        'scores': {'rows': len(scores), 'distinct_assignments': len({r['assignment_id'] for r in scores}),
                   'complete_three_role_cycle_dimensions': len(complete_pairs), 'metrics': metrics},
        'counterexamples': {
            'unequal_missingness': {'answer_weighted_mean': item_mean, 'person_weighted_mean': person_mean,
                                    'answer_weighted_favorability': item_favorable, 'person_weighted_favorability': person_favorable},
            'unpaired_vs_paired': {'separate_mean_gap': unpaired_gap, 'paired_gap': paired_gap},
            'dedup': '先排除未完成與快照日之後紀錄，再取每任務最新有效完成回覆'},
        'validation': 'PASS：鍵唯一、回覆歸屬、類別題排除、分數範圍、既有平均與配對 CSV 一致、反例驗算',
        'limits': ['三個固定 Engagement 的同人多次回覆資格仍待顧問驗收', '本機演算法已執行，未在 Qualtrics 帳號執行', 'BigQuery SQL 尚未送至 GCP 執行',
                   '正式匯出請用含時區的時間戳；本練習只用 ISO 日期與合成 response_id 排序']
    }
    target = ROOT / '教學資源/驗算結果.json'
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'completion': completion, 'score_rows': len(scores), 'paired_rows': len(complete_pairs),
                      'validation': 'PASS'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
