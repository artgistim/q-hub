# Qualtrics EX｜三 Engagement 新人關懷學習實驗室

## 零基礎先從這份開始（2026-11-08）

- [完整 HTML 學習地圖](Qualtrics_EX_零基礎學習地圖.html)：30 堂主線＋6 堂進階支線，每堂預留 10 分鐘。可搜尋、切換路線、展開課程及依來源分類；不設測驗、評分或打卡。
- [整合 Word 教材（39 頁）](docs/Qualtrics_EX_零基礎學習地圖.docx)：同一套課程、階段成果、37 題中文題庫、測試名單、指定答案、訊息範例與教材連結。

主線依序是「調查目的 → 三份問卷 → 名單與邀請 → 回答與提醒 → 通知與資料整合 → 讀圖與支持行動」。每月追蹤、主管評多人與 Lifecycle 放在進階支線。排課基準為主線 5 小時、全部 6 小時；個人重複練習、帳號準備、等待及課後閱讀另計。

新版收錄 25 篇 Qualtrics 官方、3 篇 Qualtrics 社群，以及 1 篇明確標為「其他參考教材」的 Data Revelations Likert 視覺化文章。該文僅補充觀念，不安排 Tableau 操作。HTML 圖片與 4 份練習 CSV 已內嵌，可離線閱讀與另存；外部文章需連線。

重建這兩份新版成果：`python3 -B py_code/build_learning_map.py`。使用既有 `python-docx`；共用內容在 `py_code/learning_map_content.py`。來源查核紀錄為 [學習地圖來源查核.json](docs/學習地圖來源查核.json)。舊版教材與索引保留如下。

## 既有實驗室與進階資料

開啟 [index.html](index.html)，以 **ENG_SELF、ENG_MANAGER、ENG_BUDDY 三份 Engagement 專案**練習類 360 回饋、原生邀請催填、低分 Workflow 與同一份 EX Dashboard。Lifecycle 是正式自動化對照單元。

本版依 Tim 與技術顧問方向全面調整，版本為 `v3_engagement_first`。不再以一般 Survey A/B、共用 B 問卷角色分流或 XM Directory transactions 作為主要步驟。

## 先做哪一組範例

1. 三專案基本 POC：4 位新人、4 位主管、4 位夥伴，各角色每人單期一任務，共 12 任務。從三份分角色 participant 名單開始。
2. 在 ENG_SELF Dashboard 加入另兩個 Engagement 來源，先用 Comparison widget 核對平均與 N，再驗收三角色直條。
3. 用 432 筆六個月任務規劃，與顧問驗證同主管多人及隔月再評。這份資料是業務模擬，不是已證實能直接在三個固定專案分發的名單。

首頁儀表板預設顯示 **POC 指定答案**，可切換六個月規劃。兩者均非實際平台回收；example.com 信箱不會寄信。

## 檔案位置

| 位置 | 用途 |
| --- | --- |
| index.html | 離線地圖、進度、三專案藍圖、兩組資料示範、16 課 |
| docs/操作教材.md | 三 Engagement 完整操作教材 |
| docs/帳號驗收表.csv | 18 項帳號驗收，保留既有填寫紀錄 |
| docs/全面修訂與掃描報告.md | 每個資料夾的掃描與修正結果 |
| docs/驗證報告.md | 本機測試、帳號及瀏覽器驗證界線 |
| docs/官方來源.md | 32 筆官方來源、6 張參考圖片；一般 Survey 資源標為背景 |
| data/engagement_projects.csv | 三專案建置清單，actual_project_id 可填實際 ID |
| data/engagement_participants_self_poc.csv | 新人專案 4 人名單 |
| data/engagement_participants_manager_poc.csv | 主管專案 4 人名單 |
| data/engagement_participants_buddy_poc.csv | 夥伴專案 4 人名單 |
| data/engagement_poc_assignments.csv | 12 個 POC 任務 |
| data/engagement_poc_responses.csv | 逐人填答用的指定答案，不是平台匯入範本 |
| data/engagement_poc_expected_metrics.csv | POC 四構念×三角色，12 組預期平均與 N |
| data/engagement_dashboard_mapping.csv | 三來源問卷題與共同欄位對照 |
| data/lifecycle_schedule_plan.csv | Engagement 排程與 Lifecycle 對照的業務規格 |
| data/README.md | 每組 CSV 的粒度、用途與匯入界線 |
| surveys/ | 三份獨立 Engagement 的中文單選題庫，15／11／11 題 |
| py_code/ | 無第三方依賴的資料產生器、分析與 HTML 重建 |
| tests/ | 日期、身份、題目、資料來源、POC、分析與 UI 邏輯檢查 |
| 教學資源/index.html | 49 筆進階資源，含 24 筆非官方資源與 25 筆官方對照 |
| 教學資源/技術對照與實戰練習.html | Engagement 主線與 Python／Tableau／GCP 對照 |

共 37 題全單選：34 題五選一、3 題三選一。支持需求題為無序類別，不計平均與低分警示。

## 重建與驗算

使用既有 Python 3.10+ 與 Node.js 20+，不用安裝套件。下列指令在專案根目錄執行：

```sh
python3 -B py_code/generate_data.py --as-of 2026-11-07 --seed 20261107
python3 -B py_code/analyze_data.py
python3 -B py_code/reference_assets.py
python3 -B py_code/build_site.py
python3 -B py_code/dashboard_lab.py
python3 -B py_code/build_resource_library.py
python3 -B -m unittest discover -s tests -p 'test_*.py'
node tests/test_ui.js
node tests/test_resource_ui.js
node tests/test_navigation.js
python3 -B py_code/audit_project.py
```

會覆寫同名模擬成果。手工編修資料請另存專案內新檔；`engagement_projects.csv` 的 actual_project_id 與 deployment_status 會保留。帳號驗收表不由重建器覆寫既有資料。`-B` 避免 Python cache。

`reference_assets.py` 預設只重建來源索引，保留現有圖片；只有明確加 `--download-new-images` 才重新取得 S23／S26 官方圖片。圖片是官方例圖，不是公司操作完成截圖。

本版課程進度使用獨立的 v3 Engagement 儲存鍵，不會把舊 Survey 課程完成狀態當成新版已完成；舊瀏覽器紀錄不刪除。

三頁 HTML 共用 assets/style.css；頁面內容由三個 Python renderer 產生，UI 與導覽調整已保留。直接開啟 HTML 即可；專案含個人帳號檔，不對整個資料夾啟動 HTTP 伺服器。

## 已完成與待驗收

本機已建立教材、兩組資料示範與檢查。尚未登入、建立公司專案、寄信或驗證實際帳號權限。原生三來源 Comparison 的操作依官方文件；同主管多人、固定三專案跨月、原生合併直條及 Lifecycle 延伸依帳號／顧問方案驗收。

## 官方文章 Word 與主管一對多補充

[45 頁官方文章中文指引](docs/官網重要文章參考指引/Qualtrics_EX_官方文章中文導讀與實作指引.docx) 包含 S01 至 S32 中文重點、32 張官方介面圖片、原創練習與來源連結；不是官方全文逐字翻譯。

[主管一次評多位新人](教學資源/主管一次評多位新人.html) 比較 360 Portal、Engagement 任務入口、固定三區塊與一般 Survey 迴圈。Loop & Merge 不適用 EX；一人多人多期仍須帳號驗收。Word 第 40 至 45 頁亦收錄。

重建 Word：先以 `python3 -B py_code/collect_official_guide_sources.py` 重新取得公開來源與圖片，再執行 `python3 -B py_code/build_official_guide.py`。原創內容保留在 official_guide_content.py 與 manager_batch_content.py；網站補充由 build_resource_library.py 重建。正式文件已保留，平時不需重抓來源；重新擷取後應重做內容與排版檢查，並清除本次 `.work` 暫存。
