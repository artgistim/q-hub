# 資料使用說明：三 Engagement 主線

所有資料均為虛構，is_test=1。檔案使用 UTF-8 BOM。以下把平台身份、單期練習與長期業務規劃分開。

## 單期 POC

- engagement_projects.csv：三個邏輯專案代碼，不是 API 的實際 project ID；實際 ID 可填 actual_project_id，重建時保留。
- engagement_participants_*_poc.csv：三專案各 4 位參與者；UniqueIdentifier=rater_eid。主檔沒有把 assignment 當成假員工。先對照帳號匯入範本及修改測試 Email。
- engagement_poc_assignments.csv：4 位新人、每角色一期一任務，共 12 筆。POC 選 E001–E004，各自不同主管及夥伴。
- engagement_poc_responses.csv：指定答案測試腳本，含三種題號欄位；其他角色欄位留空。response_status=scripted_expected_not_collected。可照此手填驗證，不能宣稱已回收或直接上傳平台。
- engagement_poc_expected_metrics.csv：12 組角色×構念平均、正向比例與有效 N。每組 N=4。
- engagement_dashboard_mapping.csv：四共同題與六個共同維度的來源欄位對照。實際 QID 依帳號匯出核對。

## 六個月業務規劃

- employees.csv：32 個人；relationships.csv：24 位新人的當期關係。
- assignments.csv：24×6×3=432 個規劃任務；每筆都有 project_key、project_type=Engagement、dataset_scope=six_month_planning、deployment_status=requires_repeat_response_validation。
- responses_self／manager／buddy.csv、responses_index.csv：94 筆模擬回覆，88 筆完成；未實際匯入或收集。
- scores_long.csv：352 筆完成回覆的共同構念列；空白保留，平均排除。
- summary_means.csv、paired_gaps.csv：12 組平均、52 筆完整三方的期別×構念配對。
- distribution_batch_plan.csv：按日期／專案／填答者整理的待驗證任務。native_response_permission_created=0；分批不表示平台會允許新的獨立回覆。
- simulated_ledger.csv：假設到期邀請成功的測試台帳；actions_dry_run.csv、alerts_dry_run.csv：催填與低分待辦，不是寄送證據。
- ex_participants_people.csv：全體人物識別清單，僅供核對；不能當成每個 Engagement 的收件名單。
- lifecycle_schedule_plan.csv：到期、3／7 日提醒及 Engagement／Lifecycle 方法對照；不是原生匯入格式，也沒有啟動排程。

三份同類型 Engagement 可在同一 EX Dashboard 比較。多人多期執行方式另由顧問驗證；不得僅以這些 CSV 推論三個固定專案可反覆接受同一 participant 的不同任務。
