-- v3_engagement_first：三 Engagement 的外部驗算；原生 Dashboard 主線用 Comparison widget。
-- 這些 SQL 不建立 Engagement、不授予多次回覆資格；不是必須部署的資料管線。
-- GoogleSQL / BigQuery：全部為唯讀、內嵌虛構資料，不需建立 table。
-- 可逐段貼入 BigQuery Console。尚未在 GCP 實際執行；邏輯另以 Python 驗算。
-- 日期快照以 2026-11-07 為例；正式版用含時區 timestamp 與版本化 mapping。

-- 01 任務回收率：先選有效回覆，再 LEFT JOIN 任務分母。
-- 預期 2026-10 有 2 個應交、1 個完成，完成率 0.5；11 月 20 日任務尚未到期。
WITH assignments AS (
  SELECT * FROM UNNEST([
    STRUCT('A' AS assignment_id, DATE '2026-10-31' AS due_date),
    STRUCT('B', DATE '2026-10-31'), STRUCT('C', DATE '2026-11-20')
  ])
), responses AS (
  SELECT * FROM UNNEST([
    STRUCT('A' AS assignment_id, 'R1' AS response_id, TRUE AS finished, DATE '2026-11-01' AS recorded_date),
    STRUCT('A', 'R2', FALSE, DATE '2026-11-02'),
    STRUCT('A', 'R3', TRUE, DATE '2026-12-01')
  ])
), valid_latest AS (
  SELECT * FROM responses
  WHERE finished AND recorded_date <= DATE '2026-11-07'
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY assignment_id ORDER BY recorded_date DESC, response_id DESC
  ) = 1
)
SELECT DATE_TRUNC(a.due_date, MONTH) AS due_month,
       COUNT(*) AS due_tasks,
       COUNT(r.response_id) AS completed_tasks,
       SAFE_DIVIDE(COUNT(r.response_id), COUNT(*)) AS completion_rate
FROM assignments a
LEFT JOIN valid_latest r USING (assignment_id)
WHERE a.due_date <= DATE '2026-11-07'
GROUP BY due_month;

-- 02 寬轉長：只列共同評分題，三選一支持需求題不進入 score_long。
-- UNPIVOT 的預設會排除 NULL；此處明確 INCLUDE NULLS 保留缺答供分母檢查。
-- 預期 adaptation 有效 N=1、mean=4；learning N=2、mean=3。
WITH wide AS (
  SELECT 'A' AS assignment_id, 5 AS N01, 4 AS N02, 2 AS support_need
  UNION ALL SELECT 'B', 1, CAST(NULL AS INT64), 3
), mapping AS (
  SELECT 'N01' AS question_id, 'learning' AS dimension
  UNION ALL SELECT 'N02', 'adaptation'
), long_form AS (
  SELECT assignment_id, question_id, score
  FROM wide UNPIVOT INCLUDE NULLS (score FOR question_id IN (N01, N02))
)
SELECT m.dimension, COUNTIF(l.score BETWEEN 1 AND 5) AS valid_n,
       AVG(IF(l.score BETWEEN 1 AND 5, l.score, NULL)) AS mean,
       SAFE_DIVIDE(COUNTIF(l.score IN (4, 5)), COUNTIF(l.score BETWEEN 1 AND 5)) AS favorability
FROM long_form l JOIN mapping m USING (question_id)
GROUP BY m.dimension;

-- 03 配對差距：先固定同一新人×同一期×同構念，再比較角色。
-- 預期只有 E1-M01；manager-self=1；不可由全體角色平均直接相減。
-- 正式使用前必須斷言 cycle_id×dimension×role 唯一；MAX 不能用來偷偷解決重複。
WITH scores AS (
  SELECT * FROM UNNEST([
    STRUCT('E1-M01' AS cycle_id, 'learning' AS dimension, 'self' AS role, 1 AS score),
    STRUCT('E1-M01', 'learning', 'manager', 2),
    STRUCT('E2-M01', 'learning', 'self', 5),
    STRUCT('E3-M01', 'learning', 'manager', 1)
  ])
), paired AS (
  SELECT cycle_id, dimension,
         MAX(IF(role='self', score, NULL)) AS self_score,
         MAX(IF(role='manager', score, NULL)) AS manager_score
  FROM scores GROUP BY cycle_id, dimension
)
SELECT *, manager_score - self_score AS manager_minus_self
FROM paired WHERE self_score IS NOT NULL AND manager_score IS NOT NULL;

-- 04 不等缺答造成權重差異：預期 4.2 / 3.0 / 0.8 / 0.5。
WITH items AS (
  SELECT 'A' AS person_id, value AS score FROM UNNEST([5, 5, 5, 5]) AS value
  UNION ALL SELECT 'B', 1
), per_person AS (
  SELECT person_id, AVG(score) AS mean, AVG(IF(score >= 4, 1.0, 0.0)) AS favorable
  FROM items GROUP BY person_id
)
SELECT (SELECT AVG(score) FROM items) AS answer_weighted_mean,
       (SELECT AVG(mean) FROM per_person) AS person_weighted_mean,
       (SELECT AVG(IF(score >= 4, 1.0, 0.0)) FROM items) AS answer_weighted_favorability,
       (SELECT AVG(favorable) FROM per_person) AS person_weighted_favorability;

-- 05 多對多串接前的診斷模板。先把上面測試 CTE 或自己的資料接到此查詢。
-- SELECT cycle_id, dimension, role, COUNT(*) AS rows
-- FROM your_scores GROUP BY cycle_id, dimension, role HAVING COUNT(*) > 1;
-- SELECT assignment_id, COUNT(*) AS rows
-- FROM your_assignments GROUP BY assignment_id HAVING COUNT(*) > 1;
-- 預期兩段都回傳 0 列。Tableau Relationships 與 Qualtrics mapping 都不能取代此檢查。
